
import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Users, User, ShieldCheck, Clock, Search, Filter, 
  ChevronRight, ArrowLeft, Check, X, 
  Landmark, IndianRupee, RefreshCw, Eye, 
  AlertCircle, UserPlus, Phone, Mail, MapPin, 
  Briefcase, Calendar, CheckCircle, Ban, History, Zap, Camera, Trash2,
  TrendingUp, TrendingDown, LayoutDashboard, Wallet, UserCheck,
  MoreVertical, FileText, Download, MailPlus, UserMinus, ShieldAlert,
  ArrowUpRight, PieChart, BarChart3, ListFilter, Bell, ArrowRight,
  Info, ExternalLink, MessageSquare, Send, Maximize2, ZoomIn, ZoomOut,
  ChevronLeft, CreditCard, Receipt, Settings2,
  CalendarDays, Trash, RotateCcw, Crown, Key, HardDrive, Globe, 
  Lock, Shield, Save, UserX, UserRoundPlus, HardDriveDownload,
  BarChart4, FileSpreadsheet, Printer, CalendarRange, FileDown,
  Activity, Database, Terminal, Megaphone, Link, Bold, Italic, List,
  Upload, Menu, CheckCircle2, XCircle, DatabaseBackup, EyeOff, Sparkles,
  Wifi, WifiOff, Server, MessageCircle
} from 'lucide-react';
import { profileService, UserProfile, AuditLog, PaymentRecord } from '../services/profileService';

interface AdminDashboardProps {
  onNavigate: (view: string) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'verifications' | 'payments' | 'health' | 'settings' | 'reports' | 'logs' | 'announcements'>('overview');
  const [verificationSubTab, setVerificationSubTab] = useState<'all' | 'profiles' | 'pdfs'>('all');
  const [paymentSubTab, setPaymentSubTab] = useState<'all' | 'pending' | 'completed' | 'rejected'>('pending');
  const [settingsSubTab, setSettingsSubTab] = useState<'payments' | 'notifications' | 'admins'>('payments');
  
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [allProfiles, setAllProfiles] = useState<UserProfile[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({ pending: 0, active: 0, total: 0, pendingPayments: 0 });
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  
  const [selectedItem, setSelectedItem] = useState<any>(null); // For Review Modals

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const [pendingProfiles, statsData, logsData, moderationData, paymentData] = await Promise.all([
        profileService.getPendingProfiles(verificationSubTab),
        profileService.getAdminStats(),
        profileService.getAuditLogs(),
        profileService.getAllProfilesForModeration(),
        profileService.getPayments(paymentSubTab)
      ]);
      setProfiles(pendingProfiles);
      setStats(statsData);
      setAuditLogs(logsData);
      setAllProfiles(moderationData);
      setPayments(paymentData);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [verificationSubTab, paymentSubTab, activeTab]);

  const navLinks = [
    { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'users', label: 'All Users', icon: Users },
    { id: 'verifications', label: 'Approvals', icon: ShieldCheck, count: stats.pending },
    { id: 'payments', label: 'Payments', icon: IndianRupee, count: stats.pendingPayments },
    { id: 'announcements', label: 'Announcements', icon: Megaphone },
    { id: 'health', label: 'System Health', icon: Activity },
    { id: 'reports', label: 'Reports', icon: BarChart4 },
    { id: 'logs', label: 'Logs', icon: History },
    { id: 'settings', label: 'Settings', icon: Settings2 },
  ];

  return (
    <div className="flex min-h-screen bg-gray-50 dark:bg-[#020202] font-sans transition-colors duration-500">
      
      {/* SIDEBAR */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 280 : 80 }}
        className="fixed left-0 top-0 h-screen bg-primary-950 dark:bg-[#050505] text-white z-50 flex flex-col border-r border-primary-900/30"
      >
        <div className="p-6 mb-8 flex items-center gap-4">
          <div className="bg-gold-500 text-primary-950 p-2 rounded-xl shrink-0 shadow-lg shadow-gold-500/20">
            <Shield size={24} />
          </div>
          <AnimatePresence>
            {isSidebarOpen && (
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="font-serif font-black text-xl tracking-tight whitespace-nowrap"
              >
                Lingayat<span className="text-gold-500">Sangam</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <nav className="flex-grow px-3 space-y-2">
          {navLinks.map((item) => (
            <SidebarItem 
              key={item.id}
              active={activeTab === item.id}
              label={item.label}
              icon={item.icon}
              count={item.count}
              isOpen={isSidebarOpen}
              onClick={() => setActiveTab(item.id as any)}
            />
          ))}
        </nav>

        <div className="p-4 mt-auto border-t border-primary-900/30 space-y-2">
          <button 
            onClick={() => onNavigate('landing')}
            className={`w-full flex items-center gap-4 p-4 rounded-2xl text-primary-200 hover:bg-white/5 transition-colors ${!isSidebarOpen && 'justify-center'}`}
          >
            <ArrowLeft size={20} />
            {isSidebarOpen && <span className="text-xs font-black uppercase tracking-widest">Exit Panel</span>}
          </button>
        </div>
      </motion.aside>

      {/* MAIN CONTENT AREA */}
      <main className={`flex-grow transition-all duration-300 ${isSidebarOpen ? 'ml-[280px]' : 'ml-[80px]'}`}>
        <header className="sticky top-0 z-40 bg-white/60 dark:bg-primary-950/40 backdrop-blur-2xl border-b border-gray-100 dark:border-gold-500/10 p-6 md:p-8 flex justify-between items-center">
          <div className="flex items-center gap-4">
             <h2 className="text-2xl font-serif font-black capitalize text-primary-950 dark:text-white">
               {navLinks.find(n => n.id === activeTab)?.label}
             </h2>
          </div>
          <button onClick={fetchData} className="p-3 bg-white/50 dark:bg-primary-900/30 backdrop-blur-md rounded-xl shadow-sm border border-gray-100 dark:border-white/10 text-primary-600 hover:rotate-180 transition-all duration-500">
             <RefreshCw className={isLoading ? 'animate-spin' : ''} size={18} />
          </button>
        </header>

        <div className="p-6 md:p-10 max-w-7xl mx-auto pb-32">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              {activeTab === 'overview' && <OverviewStats stats={stats} />}
              {activeTab === 'users' && <AllUsersView profiles={allProfiles} />}
              {activeTab === 'verifications' && <ApprovalsView profiles={profiles} subTab={verificationSubTab} setSubTab={setVerificationSubTab} onReview={setSelectedItem} />}
              {activeTab === 'payments' && <PaymentsView payments={payments} subTab={paymentSubTab} setSubTab={setPaymentSubTab} onVerify={setSelectedItem} />}
              {activeTab === 'health' && <SystemHealthView onRefresh={fetchData} />}
              {activeTab === 'settings' && <SettingsView subTab={settingsSubTab} setSubTab={setSettingsSubTab} />}
              {activeTab === 'announcements' && <AnnouncementsView />}
              {activeTab === 'logs' && <LogsView />}
              {activeTab === 'reports' && <ReportsView />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* GLOBAL MODALS FOR MODERATION */}
      <AnimatePresence>
        {selectedItem && selectedItem.full_name && (
          <ReviewModal 
            profile={selectedItem} 
            onClose={() => setSelectedItem(null)} 
            onAction={async (status: string, reason?: string) => {
              await profileService.updateProfileStatus(selectedItem.id, status, reason);
              setSelectedItem(null);
              fetchData();
            }}
          />
        )}
        {selectedItem && selectedItem.transaction_id && (
          <PaymentModal 
            payment={selectedItem} 
            onClose={() => setSelectedItem(null)} 
            onAction={async (status: 'completed' | 'rejected', notes?: string) => {
              await profileService.verifyPayment(selectedItem.id, selectedItem.profile_id, status, notes);
              setSelectedItem(null);
              fetchData();
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

/* --- SUB-COMPONENTS --- */

const OverviewStats = ({ stats }: any) => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
    <StatCard title="Total Profiles" value={stats.total} trend="+12" icon={Users} bg="bg-primary-50 dark:bg-primary-500/10 text-primary-600" />
    <StatCard title="Active Members" value={stats.active} trend="+18" icon={UserCheck} bg="bg-green-50 dark:bg-green-500/10 text-green-600" />
    <StatCard title="Pending Approvals" value={stats.pending} trend="-5" icon={ShieldCheck} bg="bg-orange-50 dark:bg-orange-500/10 text-orange-600" />
    <StatCard title="New Payments" value={stats.pendingPayments} trend="+2" icon={IndianRupee} bg="bg-gold-50 dark:bg-gold-500/10 text-gold-600" />
  </div>
);

const ApprovalsView = ({ profiles, subTab, setSubTab, onReview }: any) => (
  <div className="space-y-8">
    <div className="flex bg-white dark:bg-white/5 p-1.5 rounded-[2.5rem] border border-gray-100 dark:border-white/5 gap-1 w-fit shadow-inner">
      <SettingsTab active={subTab === 'all'} label="All Pending" onClick={() => setSubTab('all')} icon={ShieldCheck} />
      <SettingsTab active={subTab === 'profiles'} label="Profiles" onClick={() => setSubTab('profiles')} icon={User} />
      <SettingsTab active={subTab === 'pdfs'} label="PDFs" onClick={() => setSubTab('pdfs')} icon={FileText} />
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {profiles.map((p: any) => (
        <div key={p.id} className="bg-white dark:bg-[#0A0A0A] p-8 rounded-[3rem] border border-gray-100 dark:border-white/5 shadow-sm space-y-6 hover:shadow-xl dark:hover:border-white/10 transition-all">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gray-100 dark:bg-gray-800 overflow-hidden shrink-0"><img src={profileService.getGoogleDriveUrl(p.photo_1_file_id) || 'https://via.placeholder.com/150'} className="w-full h-full object-cover" /></div>
            <div><h4 className="font-black text-sm">{p.full_name}</h4><p className="text-[10px] text-gray-400 font-bold uppercase">{p.sub_caste}</p></div>
          </div>
          <button onClick={() => onReview(p)} className="w-full py-4 bg-primary-600 text-white rounded-2xl font-black text-xs uppercase shadow-lg shadow-primary-600/20 active:scale-95 transition-transform">Review Identity</button>
        </div>
      ))}
      {profiles.length === 0 && <p className="col-span-full py-20 text-center text-gray-400 font-black uppercase tracking-widest">Queue is clear</p>}
    </div>
  </div>
);

const PaymentsView = ({ payments, subTab, setSubTab, onVerify }: any) => (
  <div className="space-y-8">
    <div className="flex bg-white dark:bg-white/5 p-1.5 rounded-[2.5rem] border border-gray-100 dark:border-white/5 gap-1 w-fit">
      <SettingsTab active={subTab === 'pending'} label="Pending Proofs" onClick={() => setSubTab('pending')} icon={Clock} />
      <SettingsTab active={subTab === 'completed'} label="Successful" onClick={() => setSubTab('completed')} icon={CheckCircle} />
    </div>
    <div className="bg-white dark:bg-[#0A0A0A] rounded-[3rem] border border-gray-100 dark:border-white/5 shadow-sm overflow-hidden">
      <table className="w-full text-left">
        <thead className="bg-gray-50 dark:bg-white/5">
          <tr className="border-b border-gray-100 dark:border-white/5">
            <th className="p-6 text-[10px] font-black uppercase text-gray-400">TXN ID</th>
            <th className="p-6 text-[10px] font-black uppercase text-gray-400">User</th>
            <th className="p-6 text-[10px] font-black uppercase text-gray-400">Amount</th>
            <th className="p-6 text-[10px] font-black uppercase text-gray-400 text-right">Verification</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-50 dark:divide-white/5">
          {payments.map((pmt: any) => (
            <tr key={pmt.id} className="hover:bg-gray-50/30 dark:hover:bg-white/[0.02] transition-colors">
              <td className="p-6 font-black text-xs">{pmt.transaction_id}</td>
              <td className="p-6 font-bold text-sm">{pmt.profiles?.full_name}</td>
              <td className="p-6 font-black text-primary-600">₹{pmt.amount}</td>
              <td className="p-6 text-right"><button onClick={() => onVerify(pmt)} className="px-5 py-2 bg-primary-50 dark:bg-primary-500/20 text-primary-600 dark:text-primary-400 rounded-xl font-black text-[10px] uppercase">Review Proof</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

const ReviewModal = ({ profile, onClose, onAction }: any) => {
  const [reason, setReason] = useState('');
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} onClick={onClose} className="absolute inset-0 bg-black/90 backdrop-blur-md" />
      <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="relative bg-white dark:bg-[#0C0C0C] w-full max-w-2xl rounded-[3rem] p-10 space-y-8 overflow-hidden shadow-2xl border border-white/5">
         <div className="flex justify-between items-center">
            <h3 className="text-2xl font-serif font-black">Moderation Panel</h3>
            <button onClick={onClose} className="p-2 bg-gray-100 dark:bg-white/5 rounded-full hover:bg-gray-200 transition-all"><X size={20}/></button>
         </div>
         <div className="flex gap-6 items-center p-6 bg-gray-50 dark:bg-white/[0.03] rounded-3xl">
            <div className="w-20 h-20 rounded-2xl bg-gray-200 dark:bg-gray-800 overflow-hidden shrink-0"><img src={profileService.getGoogleDriveUrl(profile.photo_1_file_id) || 'https://via.placeholder.com/150'} className="w-full h-full object-cover" /></div>
            <div>
               <p className="text-xl font-black">{profile.full_name}</p>
               <p className="text-sm font-bold text-gray-500">{profile.education} • {profile.location}</p>
            </div>
         </div>
         <div className="space-y-4">
            <label className="text-xs font-black uppercase text-gray-400">Admin Notes / Rejection Reason</label>
            <textarea value={reason} onChange={e => setReason(e.target.value)} placeholder="Provide feedback if rejecting..." className="w-full h-32 p-4 bg-gray-50 dark:bg-white/[0.03] rounded-2xl border-none ring-1 ring-gray-100 dark:ring-white/10 outline-none font-bold" />
         </div>
         <div className="flex gap-4">
            <button onClick={() => onAction('active')} className="flex-1 py-4 bg-green-500 text-white rounded-2xl font-black uppercase tracking-widest shadow-lg shadow-green-500/20">Approve Profile</button>
            <button onClick={() => onAction('rejected', reason)} className="px-10 py-4 bg-red-50 dark:bg-red-500/10 text-red-600 rounded-2xl font-black uppercase tracking-widest">Reject</button>
         </div>
      </motion.div>
    </div>
  );
};

const PaymentModal = ({ payment, onClose, onAction }: any) => {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} onClick={onClose} className="absolute inset-0 bg-black/95 backdrop-blur-md" />
      <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="relative bg-white dark:bg-[#0C0C0C] w-full max-w-4xl h-[80vh] rounded-[3rem] overflow-hidden flex flex-col md:flex-row shadow-2xl border border-white/5">
         <div className="md:w-1/2 bg-black flex items-center justify-center">
            {payment.proof_url ? (
              <img src={payment.proof_url} className="max-h-full max-w-full object-contain" />
            ) : (
              <p className="text-white font-black uppercase tracking-widest text-xs opacity-50">No screenshot attached</p>
            )}
         </div>
         <div className="md:w-1/2 p-10 flex flex-col justify-between">
            <div>
               <div className="flex justify-between items-center mb-8">
                  <h3 className="text-2xl font-serif font-black">Verify Proof</h3>
                  <button onClick={onClose} className="p-2 bg-gray-100 dark:bg-white/5 rounded-full"><X size={20}/></button>
               </div>
               <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4 text-xs font-bold">
                     <span className="text-gray-400">User</span> <span>{payment.profiles?.full_name}</span>
                     <span className="text-gray-400">Amount</span> <span className="text-primary-600 font-black">₹{payment.amount}</span>
                     <span className="text-gray-400">TXN ID</span> <span className="tracking-widest">{payment.transaction_id}</span>
                  </div>
                  <p className="text-sm text-gray-500 leading-relaxed font-medium bg-primary-50 dark:bg-primary-500/10 p-4 rounded-2xl border border-primary-100 dark:border-primary-900/50">
                     Check your bank statement for a credit of <b>₹{payment.amount}</b> with reference <b>{payment.transaction_id}</b> before approving.
                  </p>
               </div>
            </div>
            <div className="flex gap-4">
               <button onClick={() => onAction('completed')} className="flex-1 py-4 bg-green-500 text-white rounded-2xl font-black uppercase shadow-lg shadow-green-500/20">Verify & Activate</button>
               <button onClick={() => onAction('rejected')} className="px-8 py-4 bg-red-50 dark:bg-red-500/10 text-red-600 rounded-2xl font-black uppercase">Reject</button>
            </div>
         </div>
      </motion.div>
    </div>
  );
};

const SystemHealthView = ({ onRefresh }: { onRefresh?: () => void }) => {
  const [healthData, setHealthData] = useState<Record<string, { status: string, message: string }>>({});
  const [isChecking, setIsChecking] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);

  const runHealthCheck = async () => {
    setIsChecking(true);
    const data = await profileService.checkSystemHealth();
    setHealthData(data);
    setIsChecking(false);
  };

  const handleSeed = async () => {
    if (!confirm("Add Deep Test Demo Data? Ensure 'profiles' and 'payments' tables exist.")) return;
    setIsSeeding(true);
    try {
      await profileService.seedDemoData();
      alert("Data seeded! Test approvals and payments now.");
      onRefresh?.();
      runHealthCheck();
    } catch (err: any) {
      alert("Seed failed: " + err.message);
    } finally {
      setIsSeeding(false);
    }
  };

  useEffect(() => { runHealthCheck(); }, []);

  return (
    <div className="space-y-8">
      <div className="bg-white dark:bg-[#0A0A0A] p-8 rounded-[3.5rem] border border-gray-100 dark:border-white/5 flex flex-col md:flex-row justify-between items-center shadow-sm gap-6">
        <div><h3 className="text-xl font-black">Database Connectivity Diagnostic</h3><p className="text-sm text-gray-400 font-bold uppercase tracking-widest">Verify RLS and Table Access</p></div>
        <div className="flex gap-4 w-full md:w-auto">
          <button onClick={handleSeed} disabled={isSeeding} className="flex-1 md:flex-none px-8 py-3 bg-gold-500 text-primary-950 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 shadow-lg disabled:opacity-50">
            {isSeeding ? <RefreshCw className="animate-spin" size={16}/> : <DatabaseBackup size={16}/>} Deep Seed
          </button>
          <button onClick={runHealthCheck} disabled={isChecking} className="flex-1 md:flex-none px-8 py-3 bg-primary-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 shadow-lg">
            {isChecking ? <RefreshCw className="animate-spin" size={16}/> : <Activity size={16}/>} Run Tests
          </button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {Object.entries(healthData).map(([table, result]: [string, any]) => (
          <div key={table} className={`p-6 rounded-[2.5rem] border-2 shadow-sm transition-all ${result.status === 'healthy' ? 'bg-green-50/30 dark:bg-green-500/[0.03] border-green-100 dark:border-green-500/20' : 'bg-red-50/30 dark:bg-red-500/[0.03] border-red-100 dark:border-red-500/20'}`}>
            <div className="flex justify-between items-start mb-4"><span className="text-[10px] font-black uppercase text-gray-400 tracking-widest">{table}</span>{result.status === 'healthy' ? <CheckCircle2 className="text-green-500" size={18}/> : <XCircle className="text-red-500" size={18}/>}</div>
            <h4 className="text-sm font-black uppercase tracking-wider mb-2">{table}</h4>
            <p className="text-xs font-bold text-gray-500 line-clamp-2">{result.message}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

const SettingsView = ({ subTab, setSubTab }: any) => {
  const [isSaving, setIsSaving] = useState(false);
  const [config, setConfig] = useState({ rzp_key_id: '', rzp_key_secret: '', rzp_webhook_secret: '', merchant_name: 'Lingayat Sangam Org', manual_upi_id: '', manual_bank_acc: '', manual_bank_ifsc: '', yearly_price: 2999 });

  useEffect(() => {
    profileService.getSettings(['rzp_key_id', 'rzp_key_secret', 'rzp_webhook_secret', 'merchant_name', 'manual_upi_id', 'manual_bank_acc', 'manual_bank_ifsc', 'yearly_price'])
      .then(s => setConfig(prev => ({ ...prev, ...s })));
  }, []);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await profileService.updateSettings(config);
      alert("Application settings committed to encrypted storage.");
    } catch (err: any) {
      alert("Save failed: " + err.message);
    } finally { setIsSaving(false); }
  };

  return (
    <div className="space-y-8">
       <div className="flex bg-white dark:bg-white/5 p-1.5 rounded-[2.5rem] border border-gray-100 dark:border-white/5 gap-1 w-fit">
          <SettingsTab active={subTab === 'payments'} icon={CreditCard} label="Payment Gateway" onClick={() => setSubTab('payments')} />
          <SettingsTab active={subTab === 'admins'} icon={Shield} label="Admin Roles" onClick={() => setSubTab('admins')} />
       </div>
       <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-8 bg-white dark:bg-[#0A0A0A] p-10 md:p-14 rounded-[3.5rem] border border-gray-100 dark:border-white/5 shadow-sm space-y-12">
             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <ConfigInput label="Razorpay Key ID" value={config.rzp_key_id} onChange={(v:any) => setConfig({...config, rzp_key_id: v})} icon={Key} />
                <ConfigInput label="Razorpay Key Secret" type="password" value={config.rzp_key_secret} onChange={(v:any) => setConfig({...config, rzp_key_secret: v})} icon={Lock} />
                <ConfigInput label="UPI ID for Manual" value={config.manual_upi_id} onChange={(v:any) => setConfig({...config, manual_upi_id: v})} icon={IndianRupee} />
                <ConfigInput label="Bank IFSC" value={config.manual_bank_ifsc} onChange={(v:any) => setConfig({...config, manual_bank_ifsc: v})} icon={Database} />
             </div>
             <button onClick={handleSave} disabled={isSaving} className="w-full py-5 bg-gold-500 text-primary-950 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl flex items-center justify-center gap-3">
                {isSaving ? <RefreshCw className="animate-spin" size={16}/> : <Save size={16}/>} Save All Credentials
             </button>
          </div>
          <div className="lg:col-span-4 bg-primary-950 dark:bg-[#080808] text-white rounded-[3rem] p-10 space-y-6 border border-white/5">
             <h4 className="text-lg font-black flex items-center gap-3"><ShieldCheck className="text-gold-500"/> Privacy Guard</h4>
             <p className="text-sm text-primary-200 leading-relaxed font-medium">All credentials stored here are encrypted and only accessible to Superadmins. If the 'app_settings' table is missing from your database, this form will fail to save.</p>
          </div>
       </div>
    </div>
  );
};

const StatCard = ({ title, value, trend, icon: Icon, bg }: any) => (
  <div className="bg-white dark:bg-[#0A0A0A] p-8 rounded-[2.5rem] border border-gray-100 dark:border-white/5 shadow-sm relative group hover:shadow-xl transition-all overflow-hidden">
    <div className="absolute top-0 right-0 p-12 bg-white/5 blur-3xl rounded-full translate-x-1/2 -translate-y-1/2" />
    <div className={`relative z-10 p-4 rounded-2xl mb-6 inline-block ${bg} group-hover:scale-110 transition-transform`}><Icon size={24}/></div>
    <p className="relative z-10 text-[10px] font-black uppercase text-gray-400 tracking-widest mb-1">{title}</p>
    <div className="relative z-10 flex items-end justify-between">
      <h4 className="text-3xl font-black">{value}</h4>
      <span className="text-[9px] font-black px-3 py-1 rounded-full bg-green-50 dark:bg-green-500/10 text-green-600">{trend}%</span>
    </div>
  </div>
);

const ConfigInput = ({ label, value, onChange, type = "text", icon: Icon }: any) => (
  <div className="space-y-3">
    <label className="text-[10px] font-black uppercase text-gray-400 ml-1 tracking-widest flex items-center gap-2">{Icon && <Icon size={12}/>} {label}</label>
    <input type={type} value={value} onChange={e => onChange(e.target.value)} className="w-full p-4 bg-gray-50 dark:bg-white/[0.03] rounded-2xl outline-none ring-1 ring-gray-100 dark:ring-white/10 font-bold text-sm focus:ring-2 focus:ring-primary-500/20 transition-all" />
  </div>
);

const SidebarItem = ({ active, label, icon: Icon, count, isOpen, onClick }: any) => (
  <button onClick={onClick} className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all relative ${active ? 'bg-gold-500 text-primary-950 shadow-lg' : 'text-primary-300 hover:bg-white/5'}`}>
    <Icon size={20} />
    {isOpen && <span className="text-[10px] font-black uppercase tracking-widest">{label}</span>}
    {count > 0 && <div className="absolute right-4 px-2 py-0.5 rounded-lg text-[8px] font-black bg-primary-950 text-gold-500">{count}</div>}
  </button>
);

const SettingsTab = ({ active, icon: Icon, label, onClick }: any) => (
  <button onClick={onClick} className={`px-6 py-3 rounded-[2rem] font-black text-[10px] uppercase tracking-widest transition-all flex items-center gap-3 ${active ? 'bg-white dark:bg-white/10 shadow-md text-primary-600 dark:text-gold-500' : 'text-gray-400'}`}>
    <Icon size={16} /> {label}
  </button>
);

/* Mock Components for minor tabs */
const LogsView = () => <div className="p-20 text-center font-black text-gray-300 uppercase tracking-widest">Audit Trails Loading...</div>;
const ReportsView = () => <div className="p-20 text-center font-black text-gray-300 uppercase tracking-widest">BI Intelligence Engine Starting...</div>;
const AnnouncementsView = () => <div className="p-20 text-center font-black text-gray-300 uppercase tracking-widest">Broadcast Console Ready</div>;
const AllUsersView = ({ profiles }: { profiles: UserProfile[] }) => (
  <div className="bg-white dark:bg-[#0A0A0A] rounded-[3rem] border border-gray-100 dark:border-white/5 shadow-sm overflow-hidden">
     <table className="w-full text-left">
        <thead className="bg-gray-50 dark:bg-white/5 border-b border-gray-100 dark:border-white/5">
           <tr>
              <th className="p-6 text-[10px] font-black uppercase text-gray-400">User</th>
              <th className="p-6 text-[10px] font-black uppercase text-gray-400">Sub-Caste</th>
              <th className="p-6 text-[10px] font-black uppercase text-gray-400">Status</th>
              <th className="p-6 text-[10px] font-black uppercase text-gray-400 text-right">Join Date</th>
           </tr>
        </thead>
        <tbody className="divide-y divide-gray-50 dark:divide-white/5">
           {profiles.map(p => (
             <tr key={p.id} className="hover:bg-gray-50/50 dark:hover:bg-white/[0.01] transition-colors">
                <td className="p-6">
                   <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-gray-100 dark:bg-gray-800 overflow-hidden shrink-0"><img src={profileService.getGoogleDriveUrl(p.photo_1_file_id) || 'https://via.placeholder.com/100'} className="w-full h-full object-cover" /></div>
                      <div><p className="font-black text-sm">{p.full_name}</p><p className="text-[10px] text-gray-400 font-bold">{p.email}</p></div>
                   </div>
                </td>
                <td className="p-6 text-xs font-bold">{p.sub_caste}</td>
                <td className="p-6"><span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase ${p.status === 'active' ? 'bg-green-50 dark:bg-green-500/10 text-green-600' : 'bg-orange-50 dark:bg-orange-500/10 text-orange-600'}`}>{p.status}</span></td>
                <td className="p-6 text-right text-xs font-bold text-gray-400">{new Date(p.created_at || '').toLocaleDateString()}</td>
             </tr>
           ))}
           {profiles.length === 0 && <tr><td colSpan={4} className="p-20 text-center text-gray-400 font-black uppercase tracking-widest">No users found</td></tr>}
        </tbody>
     </table>
  </div>
);

export default AdminDashboard;
