
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, ArrowRight, User, Calendar, MapPin, 
  Check, Loader2, Mail, Phone, Lock, Eye, EyeOff, ShieldCheck,
  ChevronRight, ChevronLeft, Upload, Info
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { profileService } from '../services/profileService';

interface CreateProfileProps {
  onNavigate: (view: string) => void;
}

const CreateProfile: React.FC<CreateProfileProps> = ({ onNavigate }) => {
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    fullName: '',
    dob: '',
    createdFor: 'Self',
    subCaste: 'Panchamasali',
    gender: 'Male',
    education: '',
    location: '',
    mobile: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg(null);

    try {
      // 1. Conflict Resolution Logic: Auto-delete matched Admin Created Profiles
      await profileService.resolveConflicts(formData.email || undefined, formData.mobile || undefined);

      // 2. Auth Signup
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
      });
      if (authError) throw authError;

      // 3. Create Profile Record
      await profileService.createProfile({
        user_id: authData.user?.id,
        full_name: formData.fullName,
        dob: formData.dob,
        created_for: formData.createdFor,
        sub_caste: formData.subCaste,
        gender: formData.gender,
        education: formData.education,
        location: formData.location,
        mobile: formData.mobile || null,
        email: formData.email || null,
        status: 'pending_approval',
        subscription_status: 'free'
      });

      alert("Registration Successful! Your profile is pending verification.");
      onNavigate('dashboard');
    } catch (err: any) {
      setErrorMsg(err.message || "An unexpected error occurred.");
    } finally {
      setIsLoading(false);
    }
  };

  const steps = [
    { title: "Account", icon: Mail },
    { title: "Personal", icon: User },
    { title: "Community", icon: ShieldCheck }
  ];

  return (
    <div className="min-h-screen bg-primary-50 dark:bg-gray-950 flex items-center justify-center py-20 px-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-4xl w-full bg-white dark:bg-gray-900 rounded-[3rem] p-8 md:p-12 shadow-2xl border border-gray-100 dark:border-gray-800"
      >
        <button onClick={() => onNavigate('landing')} className="mb-8 flex items-center gap-2 text-primary-600 font-black text-xs uppercase tracking-widest hover:translate-x-[-4px] transition-transform">
           <ArrowLeft size={16}/> BACK TO HOME
        </button>

        <h2 className="text-4xl font-serif font-black mb-10 text-center">Create Your <span className="text-primary-600">Soulmate Profile</span></h2>
        
        {/* Progress Stepper */}
        <div className="flex justify-between items-center mb-12 max-w-md mx-auto">
          {steps.map((s, idx) => (
            <div key={idx} className="flex flex-col items-center gap-2">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${step === idx + 1 ? 'bg-primary-600 text-white shadow-lg scale-110' : step > idx + 1 ? 'bg-green-500 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-400'}`}>
                {step > idx + 1 ? <Check size={18} /> : <s.icon size={18} />}
              </div>
              <span className={`text-[10px] font-black uppercase tracking-tighter ${step === idx + 1 ? 'text-primary-600' : 'text-gray-400'}`}>{s.title}</span>
            </div>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
           <AnimatePresence mode="wait">
             {step === 1 && (
               <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Input label="Email Address" name="email" value={formData.email} onChange={handleChange} placeholder="name@example.com" />
                  <div className="space-y-2 relative">
                    <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Password</label>
                    <input type={showPassword ? "text" : "password"} name="password" value={formData.password} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl border-none outline-none ring-1 ring-gray-100 dark:ring-gray-700 font-bold" />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 bottom-4 text-gray-400">{showPassword ? <EyeOff size={18}/> : <Eye size={18}/>}</button>
                  </div>
               </motion.div>
             )}

             {step === 2 && (
               <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Input label="Full Name" name="fullName" value={formData.fullName} onChange={handleChange} placeholder="As per documents" />
                  <Input label="Date of Birth" name="dob" type="date" value={formData.dob} onChange={handleChange} />
                  <Input label="Mobile Number" name="mobile" value={formData.mobile} onChange={handleChange} placeholder="+91" />
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Gender</label>
                    <select name="gender" value={formData.gender} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl border-none ring-1 ring-gray-100 dark:ring-gray-700 font-bold">
                       <option value="Male">Groom (Male)</option>
                       <option value="Female">Bride (Female)</option>
                    </select>
                  </div>
               </motion.div>
             )}

             {step === 3 && (
               <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Sub-Caste</label>
                    <select name="subCaste" value={formData.subCaste} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl border-none ring-1 ring-gray-100 dark:ring-gray-700 font-bold">
                       <option>Panchamasali</option>
                       <option>Banajiga</option>
                       <option>Jangama</option>
                       <option>Sadar</option>
                    </select>
                  </div>
                  <Input label="Education" name="education" value={formData.education} onChange={handleChange} placeholder="e.g. MBA, BE" />
                  <Input label="Current Location" name="location" value={formData.location} onChange={handleChange} placeholder="City, State" />
               </motion.div>
             )}
           </AnimatePresence>

           {errorMsg && <p className="text-red-500 text-xs font-bold text-center bg-red-50 dark:bg-red-900/20 py-3 rounded-xl">{errorMsg}</p>}

           <div className="flex justify-between gap-4 mt-12 border-t pt-8 border-gray-50 dark:border-gray-800">
             {step > 1 && <button type="button" onClick={() => setStep(step - 1)} className="px-8 py-4 bg-gray-100 dark:bg-gray-800 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-2"><ChevronLeft size={16}/> PREVIOUS</button>}
             {step < 3 ? (
               <button type="button" onClick={() => setStep(step + 1)} className="ml-auto px-10 py-4 bg-primary-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-2 shadow-xl shadow-primary-600/30">NEXT STEP <ChevronRight size={16}/></button>
             ) : (
               <motion.button 
                 whileHover={{ scale: 1.02 }}
                 whileTap={{ scale: 0.98 }}
                 disabled={isLoading} 
                 className="ml-auto px-12 py-4 bg-primary-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-2 shadow-xl shadow-primary-600/30"
               >
                 {isLoading ? <Loader2 className="animate-spin" size={16}/> : <Check size={16}/>} COMPLETE REGISTRATION
               </motion.button>
             )}
           </div>
        </form>
      </motion.div>
    </div>
  );
};

const Input = ({ label, name, value, onChange, type = "text", placeholder }: any) => (
  <div className="space-y-2">
    <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">{label}</label>
    <input 
      type={type}
      name={name}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      className="w-full p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl border-none outline-none ring-1 ring-gray-100 dark:ring-gray-700 font-bold focus:ring-2 focus:ring-primary-500/20 transition-all"
    />
  </div>
);

export default CreateProfile;
