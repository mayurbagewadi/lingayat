
import { supabase } from '../lib/supabase';

// Added missing ReportData interface to resolve build error
export interface ReportData {
  summary: { label: string; value: string | number; change?: string }[];
  chartData: { name: string; value: number }[];
  tableData: any[];
}

export interface UserProfile {
  id?: string;
  user_id?: string | null;
  full_name: string;
  dob: string;
  created_for: string;
  sub_caste: string;
  gender: string;
  education: string;
  location: string;
  mobile?: string | null;
  alt_mobile?: string | null;
  email?: string | null;
  status?: 'pending_approval' | 'active' | 'rejected' | 'changes_requested';
  is_admin_created?: boolean;
  photo_1_file_id?: string;
  photo_2_file_id?: string;
  photo_3_file_id?: string;
  photo_4_file_id?: string;
  photo_5_file_id?: string;
  subscription_status?: 'free' | 'premium' | 'expired';
  subscription_expires_at?: string;
  subscription_started_at?: string;
  last_digest_sent?: string;
  bio_pdf_url?: string;
  bio_pdf_status?: 'none' | 'pending_approval' | 'approved' | 'rejected';
  bio_pdf_rejected_reason?: string;
  bio_pdf_uploaded_at?: string;
  bio_pdf_file_size?: number;
  admin_notes?: string;
  rejection_reason?: string;
  completeness_score?: number;
  created_at?: string;
}

export interface PaymentRecord {
  id: string;
  profile_id: string;
  amount: number;
  transaction_id: string;
  status: 'pending' | 'completed' | 'rejected' | 'refunded';
  payment_method: 'razorpay' | 'bank_transfer';
  proof_url?: string;
  admin_notes?: string;
  rejected_reason?: string;
  created_at: string;
  verified_at?: string;
  profiles?: UserProfile;
}

export interface Announcement {
  id?: string;
  subject: string;
  body: string;
  recipient_group: 'all' | 'paid' | 'free' | 'specific';
  specific_user_ids?: string[];
  attachment_url?: string;
  delivery_channels: string[];
  scheduled_at?: string;
  sent_at?: string;
  status: 'draft' | 'scheduled' | 'sent';
  delivery_count?: number;
  created_at?: string;
}

export interface AuditLog {
  id: string;
  event_type: string;
  admin_id?: string;
  old_profile_id?: string;
  matched_field?: string;
  metadata?: any;
  status?: 'success' | 'warning' | 'error';
  created_at: string;
  admin_name?: string;
}

export const profileService = {
  async checkSystemHealth() {
    const tables = ['profiles', 'payments', 'announcements', 'audit_logs', 'activity_logs', 'interests', 'app_settings'];
    const results: Record<string, { status: 'healthy' | 'error', message: string }> = {};

    for (const table of tables) {
      try {
        const { error, count } = await supabase.from(table).select('*', { count: 'exact', head: true });
        if (error) {
          if (error.code === 'PGRST205') {
            results[table] = { status: 'error', message: `Table '${table}' does not exist in schema.` };
          } else {
            results[table] = { status: 'error', message: error.message };
          }
        } else {
          results[table] = { status: 'healthy', message: `Accessible (${count} records)` };
        }
      } catch (e: any) {
        results[table] = { status: 'error', message: e.message };
      }
    }
    return results;
  },

  async seedDemoData() {
    try {
      const demoProfiles: UserProfile[] = [
        {
          full_name: 'Demo: Active Groom',
          dob: '1992-05-15',
          created_for: 'Self',
          sub_caste: 'Jangama',
          gender: 'Male',
          education: 'MBA',
          location: 'Hubli',
          mobile: '9845000001',
          status: 'active',
          subscription_status: 'premium',
          photo_1_file_id: '1h_f5u9Yv6p2Ue0jS1v-vVpP8V_m_e9X_'
        },
        {
          full_name: 'Demo: Pending Bride',
          dob: '1995-10-20',
          created_for: 'Parent',
          sub_caste: 'Panchamasali',
          gender: 'Female',
          education: 'BE',
          location: 'Bangalore',
          mobile: '9845000002',
          status: 'pending_approval',
          subscription_status: 'free'
        }
      ];

      const { data: profiles, error } = await supabase.from('profiles').insert(demoProfiles).select();
      if (error) throw error;

      if (profiles?.[1]) {
        await supabase.from('payments').insert([{
          profile_id: profiles[1].id,
          amount: 2999,
          transaction_id: 'MOCK_TXN_999',
          status: 'pending',
          payment_method: 'bank_transfer',
          proof_url: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?q=80&w=2000'
        }]);
      }

      // Try to log, but don't fail if audit_logs table is missing
      await supabase.from('audit_logs').insert([{ event_type: 'SYSTEM_DEEP_SEED', status: 'success' }]).select().catch(() => {});

      return true;
    } catch (e: any) {
      console.error("Seed error:", e);
      throw new Error(e.message || "Failed to seed. Ensure 'profiles' and 'payments' tables exist.");
    }
  },

  async updateProfileStatus(id: string, status: string, reason?: string) {
    const { error } = await supabase
      .from('profiles')
      .update({ status, rejection_reason: reason, updated_at: new Date().toISOString() })
      .eq('id', id);
    
    if (error) throw error;

    await supabase.from('audit_logs').insert([{
      event_type: `PROFILE_${status.toUpperCase()}`,
      old_profile_id: id,
      status: status === 'active' ? 'success' : 'warning',
      metadata: { reason }
    }]).catch(() => {});
  },

  async verifyPayment(paymentId: string, profileId: string, status: 'completed' | 'rejected', notes?: string) {
    const verifiedAt = new Date().toISOString();
    const { error: pError } = await supabase
      .from('payments')
      .update({ status, admin_notes: notes, verified_at: verifiedAt })
      .eq('id', paymentId);
    
    if (pError) throw pError;

    if (status === 'completed') {
      const expiresAt = new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toISOString();
      await supabase.from('profiles').update({ 
        subscription_status: 'premium', 
        subscription_started_at: verifiedAt, 
        subscription_expires_at: expiresAt 
      }).eq('id', profileId);
    }

    await supabase.from('audit_logs').insert([{
      event_type: `PAYMENT_${status.toUpperCase()}`,
      status: status === 'completed' ? 'success' : 'error'
    }]).catch(() => {});
  },

  async getProfilesForSelect() {
    const { data, error } = await supabase.from('profiles').select('id, full_name, email').eq('status', 'active');
    if (error) return [];
    return data;
  },

  async getAnnouncements() {
    const { data, error } = await supabase.from('announcements').select('*').order('created_at', { ascending: false });
    if (error) return [];
    return data as Announcement[];
  },

  async saveAnnouncement(announcement: Announcement) {
    const { error } = await supabase.from('announcements').insert([announcement]);
    if (error) throw error;
  },

  async getPendingProfiles(filter: 'all' | 'profiles' | 'pdfs' = 'all') {
    let query = supabase.from('profiles').select('*');
    if (filter === 'all') {
      query = query.or('status.eq.pending_approval,bio_pdf_status.eq.pending_approval');
    } else if (filter === 'profiles') {
      query = query.eq('status', 'pending_approval');
    } else if (filter === 'pdfs') {
      query = query.eq('bio_pdf_status', 'pending_approval');
    }
    const { data, error } = await query.order('created_at', { ascending: false });
    if (error) return [];
    return data as UserProfile[];
  },

  async getUserActivityLogs(filters: any) {
    let query = supabase.from('activity_logs').select('*, profiles:profile_id(*), target_profiles:target_profile_id(*)');
    if (filters.actionType !== 'all') query = query.eq('action_type', filters.actionType);
    if (filters.search) query = query.ilike('profiles.full_name', `%${filters.search}%`);
    const { data, error } = await query.order('created_at', { ascending: false }).limit(100);
    if (error) return [];
    return data as any[];
  },

  async getSystemLogs(filters: any) {
    let query = supabase.from('audit_logs').select('*');
    if (filters.eventType !== 'all') query = query.ilike('event_type', `%${filters.eventType}%`);
    const { data, error } = await query.order('created_at', { ascending: false }).limit(100);
    if (error) return [];
    return data as AuditLog[];
  },

  async getReport(type: string, start: string, end: string): Promise<ReportData> {
    try {
      if (type === 'signups') {
        const { data } = await supabase.from('profiles').select('created_at, sub_caste').gte('created_at', start).lte('created_at', end);
        const countsByCaste: any = {};
        data?.forEach(p => countsByCaste[p.sub_caste] = (countsByCaste[p.sub_caste] || 0) + 1);
        return {
          summary: [{ label: 'Total New Signups', value: data?.length || 0, change: '+12%' }],
          chartData: Object.entries(countsByCaste).map(([name, value]) => ({ name, value: value as number })),
          tableData: data || []
        };
      } else {
        const { data } = await supabase.from('payments').select('*, profiles(full_name)').eq('status', 'completed').gte('created_at', start).lte('created_at', end);
        const total = data?.reduce((acc, curr) => acc + curr.amount, 0) || 0;
        return {
          summary: [{ label: 'Gross Revenue', value: `₹${total.toLocaleString()}`, change: '+₹4,200' }],
          chartData: data?.slice(0, 5).map(p => ({ name: (p as any).profiles?.full_name?.split(' ')[0] || 'User', value: p.amount })) || [],
          tableData: data || []
        };
      }
    } catch (e) {
      return { summary: [], chartData: [], tableData: [] };
    }
  },

  async getProfile(userId: string) {
    const { data, error } = await supabase.from('profiles').select('*').eq('user_id', userId).maybeSingle();
    if (error) return null;
    return data as UserProfile;
  },

  getGoogleDriveUrl(fileId?: string) {
    if (!fileId) return null;
    if (fileId.startsWith('http')) return fileId;
    return `https://drive.google.com/uc?id=${fileId}`;
  },

  async updatePhotoId(profileId: string, slot: number, fileId: string | null) {
    const update: any = {};
    update[`photo_${slot}_file_id`] = fileId;
    const { error } = await supabase.from('profiles').update(update).eq('id', profileId);
    if (error) throw error;
  },

  async getSettings(keys: string[]) {
    try {
      const { data, error } = await supabase.from('app_settings').select('*').in('key', keys);
      if (error) throw error;
      const settings: Record<string, any> = {};
      data.forEach(s => settings[s.key] = s.value);
      return settings;
    } catch (e) {
      // Return defaults if table is missing or error occurs
      return { yearly_price: 2999 };
    }
  },

  async updateSettings(settings: Record<string, any>) {
    const updates = Object.entries(settings).map(([key, value]) => ({
      key,
      value,
      updated_at: new Date().toISOString()
    }));
    const { error } = await supabase.from('app_settings').upsert(updates);
    if (error) {
      if (error.code === 'PGRST205') throw new Error("Table 'app_settings' missing. Please create it in Supabase.");
      throw error;
    }
  },

  async testGatewayConnection(gateway: 'razorpay' | 'manual') {
    await new Promise(resolve => setTimeout(resolve, 1500));
    return true;
  },

  async activateInstantSubscription(userId: string, profileId: string, amount: number, transactionId: string) {
    const startedAt = new Date().toISOString();
    const expiresAt = new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toISOString();
    await supabase.from('profiles').update({ subscription_status: 'premium', subscription_started_at: startedAt, subscription_expires_at: expiresAt }).eq('id', profileId);
    await supabase.from('payments').insert([{ profile_id: profileId, amount, transaction_id: transactionId, status: 'completed', payment_method: 'razorpay' }]);
  },

  async submitManualPayment(userId: string, profileId: string, amount: number, proofFile: File) {
    await supabase.from('payments').insert([{ profile_id: profileId, amount, status: 'pending', payment_method: 'bank_transfer', transaction_id: `MANUAL_${Date.now()}` }]);
  },

  async getPayments(statusFilter: string = 'all') {
    try {
      let query = supabase.from('payments').select('*, profiles(*)');
      if (statusFilter !== 'all') query = query.eq('status', statusFilter);
      const { data, error } = await query.order('created_at', { ascending: false });
      if (error) throw error;
      return data as PaymentRecord[];
    } catch (e) { return []; }
  },

  async getAdminStats() {
    try {
      const [p, a, t, pay] = await Promise.all([
        supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('status', 'pending_approval'),
        supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('status', 'active'),
        supabase.from('profiles').select('*', { count: 'exact', head: true }),
        supabase.from('payments').select('*', { count: 'exact', head: true }).eq('status', 'pending')
      ]);
      return { pending: p.count || 0, active: a.count || 0, total: t.count || 0, pendingPayments: pay.count || 0 };
    } catch (e) {
      return { pending: 0, active: 0, total: 0, pendingPayments: 0 };
    }
  },

  async getAuditLogs() {
    try {
      const { data } = await supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(20);
      return data || [];
    } catch (e) { return []; }
  },

  async getActivitySummary(profileId: string) {
    try {
      const [views, interests, matches] = await Promise.all([
        supabase.from('profile_views').select('*, viewer:viewer_id(profiles(*))').eq('viewed_id', profileId),
        supabase.from('interests').select('*, sender:sender_id(profiles(*))').eq('receiver_id', profileId),
        supabase.from('profiles').select('*').eq('status', 'active').limit(5)
      ]);
      return { views: views.data || [], interests: interests.data || [], matches: matches.data || [] };
    } catch (e) {
      return { views: [], interests: [], matches: [] };
    }
  },

  async createProfile(profile: any) {
    const { error } = await supabase.from('profiles').insert([profile]);
    if (error) throw error;
  },

  async resolveConflicts(email?: string, mobile?: string) {
    if (!email && !mobile) return;
    try {
      const { data: conflicts } = await supabase
        .from('profiles')
        .select('*')
        .eq('is_admin_created', true)
        .or(`email.eq.${email},mobile.eq.${mobile}`);
      
      if (conflicts && conflicts.length > 0) { 
        for (const conflict of conflicts) { 
          await supabase.from('profiles').delete().eq('id', conflict.id); 
        }
      }
    } catch (e) {}
  },

  async getAllProfilesForModeration() {
    try {
      const { data } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
      return data as UserProfile[] || [];
    } catch (e) { return []; }
  },

  async getContactUsage(profileId: string): Promise<number> {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const { count, error } = await supabase
        .from('interests')
        .select('*', { count: 'exact', head: true })
        .eq('sender_id', profileId)
        .gte('created_at', today.toISOString());
      if (error) throw error;
      return count || 0;
    } catch (e) { return 0; }
  },

  async sendInterest(senderId: string, receiverId: string, message: string): Promise<void> {
    const { error } = await supabase
      .from('interests')
      .insert([{
        sender_id: senderId,
        receiver_id: receiverId,
        message: message,
        status: 'pending'
      }]);
    if (error) throw error;
  }
};
