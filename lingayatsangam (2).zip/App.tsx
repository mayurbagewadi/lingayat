
import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import VachanaSection from './components/VachanaSection';
import AIBioGenerator from './components/AIBioGenerator';
import Testimonials from './components/Testimonials';
import Footer from './components/Footer';
import Login from './components/Login';
import CreateProfile from './components/CreateProfile';
import AdminDashboard from './components/AdminDashboard';
import UserDashboard from './components/UserDashboard';
import ProfileBrowsing from './components/ProfileBrowsing';
import UpgradeToPremium from './components/UpgradeToPremium';
import NotFound from './components/NotFound';
import { supabase } from './lib/supabase';

const PageTransition: React.FC<{ children: React.ReactNode, className?: string }> = ({ children, className = "" }) => (
  <motion.div
    initial={{ opacity: 0, scale: 0.98, filter: 'blur(5px)' }}
    animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
    exit={{ opacity: 0, scale: 1.02, filter: 'blur(5px)' }}
    transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
    className={className}
  >
    {children}
  </motion.div>
);

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState('landing');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [session, setSession] = useState<any>(null);
  const [profileId, setProfileId] = useState<string | null>(null);

  const fetchProfileId = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id')
        .eq('user_id', userId)
        .maybeSingle();
      
      if (data) setProfileId(data.id);
    } catch (err) {
      console.error("Error fetching profile ID:", err);
    }
  };

  useEffect(() => {
    if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
    } else {
      setIsDarkMode(false);
      document.documentElement.classList.remove('dark');
    }

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session) {
        fetchProfileId(session.user.id);
        setCurrentView('dashboard');
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session) {
        fetchProfileId(session.user.id);
        if (currentView === 'login') setCurrentView('dashboard');
      } else {
        setProfileId(null);
      }
    });

    return () => subscription.unsubscribe();
  }, [currentView]);

  const toggleTheme = () => {
    if (isDarkMode) {
      document.documentElement.classList.remove('dark');
      localStorage.theme = 'light';
      setIsDarkMode(false);
    } else {
      document.documentElement.classList.add('dark');
      localStorage.theme = 'dark';
      setIsDarkMode(true);
    }
  };

  const handleNavigate = (view: string) => {
    setCurrentView(view);
    window.scrollTo(0, 0);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setCurrentView('landing');
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-950 text-gray-800 dark:text-gray-100 font-sans selection:bg-primary-200 selection:text-primary-900 transition-colors duration-500">
      <AnimatePresence mode="wait">
        {currentView === 'landing' && (
          <PageTransition key="landing">
            <Navbar onNavigate={handleNavigate} isDarkMode={isDarkMode} toggleTheme={toggleTheme} session={session} onLogout={handleLogout} />
            <main>
              <Hero onNavigate={handleNavigate} />
              <Features />
              <VachanaSection />
              <AIBioGenerator />
              <Testimonials />
            </main>
            <Footer />
          </PageTransition>
        )}

        {currentView === 'login' && (
          <PageTransition key="login">
            <Login onNavigate={handleNavigate} />
          </PageTransition>
        )}

        {currentView === 'register' && (
          <PageTransition key="register">
            <CreateProfile onNavigate={handleNavigate} />
          </PageTransition>
        )}

        {currentView === 'dashboard' && session && (
          <PageTransition key="dashboard">
            <Navbar onNavigate={handleNavigate} isDarkMode={isDarkMode} toggleTheme={toggleTheme} session={session} onLogout={handleLogout} />
            <UserDashboard onNavigate={handleNavigate} user={session.user} />
          </PageTransition>
        )}

        {currentView === 'browse' && (
          <PageTransition key="browse">
            <Navbar onNavigate={handleNavigate} isDarkMode={isDarkMode} toggleTheme={toggleTheme} session={session} onLogout={handleLogout} />
            <ProfileBrowsing onNavigate={handleNavigate} />
          </PageTransition>
        )}

        {currentView === 'subscription' && session && (
          <PageTransition key="subscription">
            <Navbar onNavigate={handleNavigate} isDarkMode={isDarkMode} toggleTheme={toggleTheme} session={session} onLogout={handleLogout} />
            {profileId ? (
              <UpgradeToPremium onNavigate={handleNavigate} user={session.user} profileId={profileId} />
            ) : (
              <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-black">
                <div className="flex flex-col items-center gap-4">
                  <div className="w-12 h-12 border-4 border-primary-600 border-t-transparent rounded-full animate-spin"></div>
                  <p className="font-bold text-gray-500">Initializing your membership details...</p>
                </div>
              </div>
            )}
          </PageTransition>
        )}

        {currentView === 'admin' && (
          <PageTransition key="admin">
            <AdminDashboard onNavigate={handleNavigate} />
          </PageTransition>
        )}

        {currentView === 'not-found' && (
          <PageTransition key="not-found">
            <NotFound onNavigate={handleNavigate} />
          </PageTransition>
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;
